<template>
    <div class="masonry-item masonry-hr-style">
        <slot></slot>
    </div>
</template>