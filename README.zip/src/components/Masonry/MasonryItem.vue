<template>
    <div class="masonry-item masonry-item-style px-2 py-2">
        <slot></slot>
    </div>
</template>