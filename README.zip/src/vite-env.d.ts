/// <reference types="vite/client" />
declare module 'swiper/css';