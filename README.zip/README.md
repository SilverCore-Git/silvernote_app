# silvernote

- vue js
- typescript
- tailwindcss
- tiptap
- electron-forge
- capacitor
- express
